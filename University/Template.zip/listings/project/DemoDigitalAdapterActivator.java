public void start(BundleContext context) throws Exception {
    this.context = context;
    digitalAdapter = new DemoDigitalAdapter("1");

    serviceTracker = new ServiceTracker<>(this.context, DigitalTwin.class.getName(), new ServiceTrackerCustomizer<>() {
        @Override
        public Object addingService(ServiceReference<Object> reference) {
            ServiceRegistration<?> serviceRegistration = context.registerService(DigitalAdapter.class.getName(),digitalAdapter, null);
            digitalTwin = (DigitalTwin) context.getService(reference);
            digitalAdapter.onAdapterStart();
            return serviceRegistration;
        }

        @Override
        public void removedService(ServiceReference<Object> reference, Object service) {
            digitalAdapter.onAdapterStop();
            ServiceRegistration<?> registration = (ServiceRegistration) service;
            registration.unregister();
            context.ungetService(reference);
        }
    });
    serviceTracker.open();
}