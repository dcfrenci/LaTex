package org.digitaltwin.adapter.digital;

import org.digitaltwin.adapter.physical.PhysicalAssetDescription;
import org.digitaltwin.core.LifeCycleListener;
import org.digitaltwin.core.state.DigitalTwinStateProperty;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public abstract class DigitalAdapter implements DigitalAdapterListener {


    Map<String, PhysicalAssetDescription> physicalAssetDescriptionMap;


    private String ID;

    public DigitalAdapter(String ID) {
        this.ID = ID;
        physicalAssetDescriptionMap = new HashMap<>();
    }

    public String getID() {
        return ID;
    }

    public abstract void onAdapterStart();

    public abstract void onAdapterStop();


    public abstract void onStateChangePropertyCreated(DigitalTwinStateProperty<?> digitalTwinStateProperty);

    public abstract void onStateChangePropertyUpdate(DigitalTwinStateProperty<?> digitalTwinStateProperty);
    public abstract void onStateChangePropertyRemove(DigitalTwinStateProperty<?> digitalTwinStateProperty);
    @Override
    public void onPropertyCreated(DigitalTwinStateProperty<?> digitalTwinStateProperty) {
        onStateChangePropertyCreated(digitalTwinStateProperty);

    }

    @Override
    public void onPropertyUpdate(DigitalTwinStateProperty<?> digitalTwinStateProperty) {
        onStateChangePropertyUpdate(digitalTwinStateProperty);
    }

    @Override
    public void onPropertyRemove(DigitalTwinStateProperty<?> digitalTwinStateProperty) {
        onStateChangePropertyRemove(digitalTwinStateProperty);
    }
}
