package org.demodigitaltwin;

import org.digitaltwin.adapter.digital.DigitalAdapter;
import org.digitaltwin.adapter.physical.PhysicalAdapter;
import org.digitaltwin.core.DigitalTwin;
import org.digitaltwin.core.model.ShadowingModelFunction;
import org.osgi.framework.*;
import org.osgi.util.tracker.ServiceTracker;
import org.osgi.util.tracker.ServiceTrackerCustomizer;

import java.util.*;

public class DigitalTwinActivator implements BundleActivator{

    private BundleContext context;
    private DigitalTwin digitalTwin = null;

    private ServiceTracker physicalAdapterServiceTracker;

    private ServiceTracker<DigitalAdapter,DigitalAdapter> digitalAdapterServiceTracker;

    private ServiceTracker shadowingModelFunctionServiceTracker;




    @Override
    public void start(BundleContext context) throws Exception {
        this.context = context;



     physicalAdapterServiceTracker = new ServiceTracker<>(context, PhysicalAdapter.class.getName(), new ServiceTrackerCustomizer<>() {
         @Override
         public Object addingService(ServiceReference<Object> reference) {
             PhysicalAdapter newPhysicalAdapter = (PhysicalAdapter) context.getService(reference);
             if(digitalTwin != null){
                 digitalTwin.addPhysicalAdapter(newPhysicalAdapter);
             }

             return newPhysicalAdapter;
         }

         @Override
         public void modifiedService(ServiceReference<Object> reference, Object service) {

         }

         @Override
         public void removedService(ServiceReference<Object> reference, Object service) {
             digitalTwin.removePhysicalAdapter((PhysicalAdapter) service);
         }


        });

        digitalAdapterServiceTracker = new ServiceTracker<DigitalAdapter, DigitalAdapter>(context, DigitalAdapter.class.getName(), new ServiceTrackerCustomizer<DigitalAdapter, DigitalAdapter>() {
            @Override
            public DigitalAdapter addingService(ServiceReference<DigitalAdapter> reference) {
                DigitalAdapter newDigitalAdapter = context.getService(reference);
                if(digitalTwin != null){
                    digitalTwin.addDigitalAdapter(newDigitalAdapter);
                }
                return newDigitalAdapter;
            }

            @Override
            public void modifiedService(ServiceReference<DigitalAdapter> reference, DigitalAdapter service) {

            }

            @Override
            public void removedService(ServiceReference<DigitalAdapter> reference, DigitalAdapter service) {
               digitalTwin.removeDigitalAdapter(service);
            }
        });





        shadowingModelFunctionServiceTracker = new ServiceTracker<>(context, ShadowingModelFunction.class.getName(), new ServiceTrackerCustomizer<>() {
            @Override
            public Object addingService(ServiceReference<Object> reference) {
                ShadowingModelFunction shadowingModelFunction = (ShadowingModelFunction) context.getService(reference);
                digitalTwin = new DigitalTwin(String.valueOf(new Random().nextInt()), shadowingModelFunction);
                return context.registerService(DigitalTwin.class.getName(), digitalTwin, null);
            }

            @Override
            public void modifiedService(ServiceReference<Object> reference, Object service) {

            }

            @Override
            public void removedService(ServiceReference<Object> reference, Object service) {
                ServiceRegistration<?> registration = (ServiceRegistration) service;
                registration.unregister();
                context.ungetService(reference);
            }
        });

        physicalAdapterServiceTracker.open();
        digitalAdapterServiceTracker.open();
        shadowingModelFunctionServiceTracker.open();




    }

    @Override
    public void stop(BundleContext context) throws Exception {
       physicalAdapterServiceTracker.close();
       digitalAdapterServiceTracker.close();
       shadowingModelFunctionServiceTracker.close();
    }






}
