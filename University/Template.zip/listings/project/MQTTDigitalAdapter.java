public class MQTTDigitalAdapter extends DigitalAdapter {

    private IMqttClient publisher;
    private static final String TOPIC = "digitaltwin/properties/";

    @Override
    public void onAdapterStart() {
        String publisherId = UUID.randomUUID().toString();
        publisher = new MqttClient("tcp://test.mosquitto.org:1883", publisherId);
        try {
            publisher.connect();
        } catch (MqttException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void onStateChangePropertyCreated(DigitalTwinStateProperty<?> digitalTwinStateProperty) {
        if (publisher.isConnected()){
            byte[] payload = String.format("T:%04.2f", digitalTwinStateProperty.getValue()).getBytes();
            MqttMessage msg = new MqttMessage(payload);
            try {
                publisher.publish(TOPIC + digitalTwinStateProperty.getKey(),msg);
            } catch (MqttException e) {
                throw new RuntimeException(e);
            }
        }
    }

    @Override
    public void onStateChangePropertyUpdate(DigitalTwinStateProperty<?> digitalTwinStateProperty) {
      // uguale a onStateChangePropertyCreated
    }
}
