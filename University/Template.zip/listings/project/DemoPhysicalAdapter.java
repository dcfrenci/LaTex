public class DemoPhysicalAdapter extends PhysicalAdapter {

    private final Thread thread;

    public DemoPhysicalAdapter(String ID, IotDevice iotDevice) {
        thread = new Thread(() -> {
            try {
                while (!Thread.currentThread().isInterrupted()){
                    iotDevice.setValue(iotDevice.getValue() + new Random().nextDouble(-1,1));
                    Thread.sleep(5000);
                }
            } catch (Exception ignored){ }
        });
    }

    @Override
    public void onAdapterStart() {
        thread.start();
    }

    @Override
    public void onAdapterStop() {
        if(thread.isAlive()){
            thread.interrupt();
        }
    }

    @Override
    public void onAdapterCreate() {
        getIotDevice().generatePad();
        onAdapterStart();
    }
}
