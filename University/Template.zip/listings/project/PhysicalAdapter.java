public abstract class PhysicalAdapter implements Observer{

    public PhysicalAdapter(String ID, IotDevice iotDevice) {
        this.ID = ID;
        this.iotDevice = iotDevice;
        this.iotDevice.registerObserver(this);
    }

    @Override
    public void update(String property, Double value, Boolean bound) {
        PhysicalAssetDescription pad = new PhysicalAssetDescription();
        pad.getProperties().add(new PhysicalAssetProperty<>(property, value));
        setPhysicalAssetDescription(pad);
        if (!bound){
            notifyPhysicalAdapterUpdate(getPhysicalAssetDescription());
        }else {
            notifyPhysicalAdapterBound(getPhysicalAssetDescription());
        }
    }

    protected void notifyPhysicalAdapterBound(PhysicalAssetDescription physicalAssetDescription) {
        if(getPhysicalAdapterListener() != null)
            getPhysicalAdapterListener().onPhysicalAdapterBound(getID(), this.physicalAssetDescription);
    }

    protected void notifyPhysicalAdapterUpdate(PhysicalAssetDescription physicalAssetDescription) {
        if(getPhysicalAdapterListener() != null)
            getPhysicalAdapterListener().onPhysicalAdapterUpdate(getID(),physicalAssetDescription);
    }
}

