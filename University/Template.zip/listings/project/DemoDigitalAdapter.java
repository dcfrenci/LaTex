public class DemoDigitalAdapter extends DigitalAdapter {

    @Override
    public void onStateChangePropertyCreated(DigitalTwinStateProperty<?> digitalTwinStateProperty) {
        System.out.println("(Digital Adapter stop " + getID() + "): Property created { name :" + digitalTwinStateProperty.getKey() + "; value: " + digitalTwinStateProperty.getValue() + " }");
    }

    @Override
    public void onStateChangePropertyUpdate(DigitalTwinStateProperty<?> digitalTwinStateProperty) {
        System.out.println("(Digital Adapter " + getID() + "): Property update { name :" + digitalTwinStateProperty.getKey() + "; value: " + digitalTwinStateProperty.getValue() + " }");
    }

    @Override
    public void onStateChangePropertyRemove(DigitalTwinStateProperty<?> digitalTwinStateProperty) {
        System.out.println("(Digital Adapter " + getID() + "): Property removed { name :" + digitalTwinStateProperty.getKey() + "; value: " + digitalTwinStateProperty.getValue() + " }");
    }
}
