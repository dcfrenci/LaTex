package org.physicaladapter;

import org.digitaltwin.adapter.physical.PhysicalAdapter;
import org.digitaltwin.adapter.physical.PhysicalAdapterListener;
import org.digitaltwin.core.DigitalTwin;
import org.digitaltwin.iotdevice.IotDevice;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.framework.ServiceRegistration;
import org.osgi.util.tracker.ServiceTracker;
import org.osgi.util.tracker.ServiceTrackerCustomizer;

import java.util.*;

public class DemoPhysicalAdapterActivator implements BundleActivator {

    private ServiceTracker serviceTracker;

    private DemoPhysicalAdapter physicalAdapter;


    private DigitalTwin digitalTwin;

    @Override
    public void start(BundleContext context) throws Exception {

        IotDevice iotDevice = new IotDevice("Temperature", 20.0);
        physicalAdapter = new DemoPhysicalAdapter("1", iotDevice);


        serviceTracker = new ServiceTracker(context, DigitalTwin.class.getName(), new ServiceTrackerCustomizer() {
            @Override
            public Object addingService(ServiceReference reference) {
                ServiceRegistration<?> serviceRegistration = context.registerService(PhysicalAdapter.class.getName(), physicalAdapter, null);
                digitalTwin = (DigitalTwin) context.getService(reference);
                physicalAdapter.onAdapterCreate();
                return serviceRegistration;
            }

            @Override
            public void modifiedService(ServiceReference reference, Object service) {

            }

            @Override
            public void removedService(ServiceReference reference, Object service) {
                physicalAdapter.onAdapterStop();
                ServiceRegistration<?> registration = (ServiceRegistration) service;
                registration.unregister();
                context.ungetService(reference);
            }
        });
        serviceTracker.open();
    }

    @Override
    public void stop(BundleContext context) throws Exception {
        serviceTracker.close();
        physicalAdapter.onAdapterStop();
    }









}
