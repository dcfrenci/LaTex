public class DemoShadowingFunctionActivator implements BundleActivator{

    @Override
    public void start(BundleContext context) throws Exception {
        DemoShadowingFunction demoShadowingFunction = new DemoShadowingFunction("1", context);
        context.registerService(ShadowingModelFunction.class.getName(), demoShadowingFunction, null);
    }

    @Override
    public void stop(BundleContext context) throws Exception { }
}
