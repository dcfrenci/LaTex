public class DemoShadowingFunction extends ShadowingModelFunction {
    
    @Override
    public void onCreate() { }

    @Override
    public void onStart() { }

    @Override
    public void onStop() { }

}
